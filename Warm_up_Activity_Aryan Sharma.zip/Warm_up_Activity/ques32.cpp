#include <iostream>
#include <vector>
#include <map>

using namespace std;

map<int, int> countFrequency(const vector<int> &arr)
{
    map<int, int> frequencyMap;

    for (int num : arr)
    {
        frequencyMap[num]++;
    }

    return frequencyMap;
}

int main()
{

    vector<int> arr = {1, 2, 3, 4, 2, 3, 1, 2, 4, 5, 5};

    map<int, int> frequencyMap = countFrequency(arr);

    cout << "Element frequencies:\n";
    for (const auto &pair : frequencyMap)
    {
        cout << pair.first << ": " << pair.second << " times\n";
    }

    return 0;
}
