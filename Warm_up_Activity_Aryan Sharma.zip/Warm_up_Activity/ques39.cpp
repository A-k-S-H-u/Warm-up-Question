#include <iostream>

using namespace std;

const int MAX_ROWS = 10;
const int MAX_COLS = 10;

bool isSparseMatrix(int matrix[MAX_ROWS][MAX_COLS], int rows, int cols)
{
    int countZeros = 0;

    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            if (matrix[i][j] == 0)
            {
                countZeros++;
            }
        }
    }

    return (countZeros > (rows * cols) / 2);
}

int main()
{
    int matrix[MAX_ROWS][MAX_COLS];
    int rows, cols;

    cout << "Enter the number of rows: ";
    cin >> rows;
    cout << "Enter the number of columns: ";
    cin >> cols;

    cout << "Enter the elements of the matrix:" << endl;
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            cout << "Enter element at position " << i + 1 << "," << j + 1 << ": ";
            cin >> matrix[i][j];
        }
    }

    if (isSparseMatrix(matrix, rows, cols))
    {
        cout << "The matrix is a sparse matrix." << endl;
    }
    else
    {
        cout << "The matrix is not a sparse matrix." << endl;
    }

    return 0;
}
