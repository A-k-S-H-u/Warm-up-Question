#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    while (n >= 1)
    {
        cout << n << " ";
        n--;
    }
    return 0;
}