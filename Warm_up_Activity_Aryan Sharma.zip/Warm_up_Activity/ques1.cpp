#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, y, w, d;
    cout << " Enter the Number of days" << endl;
    cin >> n;

    y = n / 365;
    w = (n % 365) / 7;
    d = n - (y * 365 + w * 7);

    cout << "No of years " << y << endl;
    cout << "No of Weeks " << w << endl;
    cout << "No of days  " << d << endl;

    return 0;
}