#include <iostream>
#include <bitset>

using namespace std;

class Solution
{
public:
    int solution(int N)
    {
        // Convert the integer to its binary representation
        bitset<32> binaryRepresentation(N);
        string binaryString = binaryRepresentation.to_string();

        int longestGap = 0;
        int currentGap = 0;
        bool inGap = false;

        // Iterate through the binary string to find the longest binary gap
        for (char bit : binaryString)
        {
            if (bit == '1')
            {
                if (inGap)
                {
                    longestGap = max(longestGap, currentGap);
                    currentGap = 0;
                }
                else
                {
                    inGap = true;
                }
            }
            else
            {
                if (inGap)
                {
                    currentGap++;
                }
            }
        }

        return longestGap;
    }
};

int main()
{
    Solution solution;

    int N;

    cout << "Enter a positive integer N: ";
    cin >> N;

    int result = solution.solution(N);

    cout << "The length of the longest binary gap in N is: " << result << endl;

    return 0;
}
