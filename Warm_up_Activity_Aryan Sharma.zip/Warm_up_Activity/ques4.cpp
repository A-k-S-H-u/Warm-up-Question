#include <bits/stdc++.h>
using namespace std;

int main()
{
    int num;
    cin >> num;
    if (num & 1)
    {
        cout << "LSB of " << num << " is set ";
    }

    else
    {
        cout << "LSB is not set" << endl;
    }
}