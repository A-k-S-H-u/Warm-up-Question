#include <iostream>
#include <string>
#include <sstream>
#include <stack>

using namespace std;

string reverseWords(const string &inputString)
{
    stringstream ss(inputString);
    stack<string> wordsStack;
    string word, reversedString;

    while (ss >> word)
    {
        wordsStack.push(word);
    }

    while (!wordsStack.empty())
    {
        reversedString += wordsStack.top() + " ";
        wordsStack.pop();
    }

    if (!reversedString.empty())
    {
        reversedString.pop_back();
    }

    return reversedString;
}

int main()
{
    string inputString;

    cout << "Enter a string: ";
    getline(cin, inputString);

    string reversedString = reverseWords(inputString);

    cout << "Reversed order of words: " << reversedString << endl;

    return 0;
}
