#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, reversed = 0, remainder, original;
    cout << "Enter an integer" << endl;
    cin >> n;
    original = n;

    // reversed integer is stored in reversed variable
    while (n != 0)
    {
        remainder = n % 10;
        reversed = reversed * 10 + remainder;
        n /= 10;
    }

    // palindrome if orignal and reversed are equal
    if (original == reversed)
        cout << original << " is a Palinndrome.";
    else
        cout << original << " is not a Palindrome";
    return 0;
}