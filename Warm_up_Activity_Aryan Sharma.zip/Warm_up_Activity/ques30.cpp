#include <iostream>

using namespace std;


void readArray(int arr[], int size, int index)
{
    if (index == size)
    {
        return; 
    }

   
    cout << "Enter element at index " << index << ": ";
    cin >> arr[index];

   
    readArray(arr, size, index + 1);
}


void printArray(int arr[], int size, int index)
{
    if (index == size)
    {
        return; 
    }

   
    cout << arr[index] << " ";

   
    printArray(arr, size, index + 1);
}

int main()
{
    const int maxSize = 100; 
    int arr[maxSize];
    int size;

    cout << "Enter the size of the array: ";
    cin >> size;

   
    readArray(arr, size, 0);

   
    cout << "Elements of the array: ";
    printArray(arr, size, 0);

    return 0;
}
