#include <bits/stdc++.h>
using namespace std;

int main()
{
    char c;
    int lowercase_vowel, uppercase_vowel;
    cin >> c;
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
    {
        if (c >= 65 && c <= 90)
        {
            cout << "Charcter is Uppercase Alphabet ";
            uppercase_vowel = (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U');

            if (uppercase_vowel)
            {
                cout << "and charcter is uppercase Vowel" << endl;
            }
            else
            {
                cout << " and not a vowel" << endl;
            }
        }
        else
        {
            cout << "charcter is Lowercase Alphabet";
            lowercase_vowel = (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u');
            if (lowercase_vowel)
            {
                cout << " and charcter is lowercase vowel" << endl;
            }

            else
            {
                cout << " and not a vowel" << endl;
            }
        }
    }

    else
    {
        cout << "Not an alphabet" << endl;
    }
    return 0;
}