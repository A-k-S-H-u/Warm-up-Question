// #include <iostream>
// #include <vector>

// using namespace std;

// class Solution
// {
// public:
//     int solution(vector<int> &A)
//     {
//         long long expectedSum = (A.size() + 1) * (A.size() + 2) / 2; // Sum of first (N + 1) natural numbers
//         long long actualSum = 0;

//         for (int num : A)
//         {
//             actualSum += num;
//         }

//         return static_cast<int>(expectedSum - actualSum);
//     }
// };

// int main()
// {
//     Solution solution;

//         vector<int> A = {2, 3, 1, 5};
//     int missingElement = solution.solution(A);

//     cout << "Missing element: " << missingElement << endl;

//     return 0;
// }

#include <bits/stdc++.h>
using namespace std;

int main()
{
    int arr[] = {9, 3, 9, 3, 9, 7, 9};
    int sum = 0;
    for (int i = 0; i < 7; i++)
    {
        sum ^= arr[i];
    }

    cout << sum << endl;
    return 0;
}
