#include <bits/stdc++.h>
using namespace std;
int power(int x, int n)
{
    int ans = 1;
    for (int i = 0; i < n; i++)
    {
        ans = ans * x;
    }

    return ans;
}

int main()
{
    int x, n;
    cin >> x >> n;
    cout << "The Answer is " << power(x, n);
    return 0;
}