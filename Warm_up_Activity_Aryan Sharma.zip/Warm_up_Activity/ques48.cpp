#include <iostream>
#include <vector>
#include <unordered_map>

using namespace std;

class Solution
{
public:
    int solution(vector<int> &A)
    {
        unordered_map<int, int> occurrences;

        for (int num : A)
        {
            occurrences[num]++;
        }

        for (const auto &entry : occurrences)
        {
            if (entry.second % 2 != 0)
            {
                return entry.first;
            }
        }

        return -1;
    }
};

int main()
{
    Solution solution;

    int N;
    cout << "Enter the size of the array (odd): ";
    cin >> N;

    vector<int> A(N);

    cout << "Enter the elements of the array:" << endl;
    for (int i = 0; i < N; i++)
    {
        cin >> A[i];
    }

    int result = solution.solution(A);

    cout << "The unpaired element in the array is: " << result << endl;

    return 0;
}
