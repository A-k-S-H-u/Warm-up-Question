#include <bits/stdc++.h>
using namespace std;

int main()
{
    int amt;
    cin >> amt;
    int five_hundred = amt / 500;
    amt %= 500;
    int two_hundred = amt / 200;
    amt %= 200;
    int hundred = amt / 100;
    amt %= 100;
    int fifty = amt / 50;
    amt %= 50;
    int twenty = amt / 20;
    amt %= 20;
    int ten = amt / 10;
    amt %= 10;
    int five = amt / 5;
    amt %= 5;
    int two = amt / 2;
    amt %= 2;
    int one = amt / 1;

    cout << "five Hunderd Notes : " << five_hundred << endl;
    cout << "two Hunderd Notes : " << two_hundred << endl;
    cout << "Hundred Notes : " << hundred << endl;
    cout << "fifty Notes : " << fifty << endl;
    cout << "Twenty Notes : " << twenty << endl;
    cout << "ten Notes : " << ten << endl;
    cout << "five Notes : " << five << endl;
    cout << "two notes : " << two << endl;
    cout << "one Notes : " << one << endl;
    return 0;
}