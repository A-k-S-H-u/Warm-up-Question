#include <iostream>
#include <string>
#include <sstream>

using namespace std;

string trimWhitespace(const string &inputString)
{
    stringstream ss(inputString);
    string trimmedString, word;

    while (ss >> word)
    {
        trimmedString += word + " ";
    }

    if (!trimmedString.empty())
    {
        trimmedString.pop_back();
    }

    return trimmedString;
}

int main()
{
    string inputString;

    cout << "Enter a string: ";
    getline(cin, inputString);

    string trimmedString = trimWhitespace(inputString);

    cout << "String after trimming whitespace: " << trimmedString << endl;

    return 0;
}
