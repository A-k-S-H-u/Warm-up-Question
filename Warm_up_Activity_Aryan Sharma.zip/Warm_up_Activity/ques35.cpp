#include <iostream>
#include <vector>

using namespace std;

vector<vector<int>> multiplyMatrices(const vector<vector<int>> &mat1, const vector<vector<int>> &mat2)
{
    int rows1 = mat1.size();
    int cols1 = mat1[0].size();
    int rows2 = mat2.size();
    int cols2 = mat2[0].size();

    if (cols1 != rows2)
    {
        cerr << "Error: Matrices cannot be multiplied. Invalid dimensions." << endl;
        exit(1);
    }

    vector<vector<int>> result(rows1, vector<int>(cols2, 0));

    for (int i = 0; i < rows1; ++i)
    {
        for (int j = 0; j < cols2; ++j)
        {
            for (int k = 0; k < cols1; ++k)
            {
                result[i][j] += mat1[i][k] * mat2[k][j];
            }
        }
    }

    return result;
}

// Function to print a matrix
void printMatrix(const vector<vector<int>> &mat)
{
    int rows = mat.size();
    int cols = mat[0].size();

    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }
}

int main()
{
    int rows1, cols1, rows2, cols2;

    cout << "Enter the dimensions of the first matrix (rows columns): ";
    cin >> rows1 >> cols1;

    cout << "Enter the elements of the first matrix:" << endl;
    vector<vector<int>> matrix1(rows1, vector<int>(cols1));
    for (int i = 0; i < rows1; ++i)
    {
        for (int j = 0; j < cols1; ++j)
        {
            cin >> matrix1[i][j];
        }
    }

    cout << "Enter the dimensions of the second matrix (rows columns): ";
    cin >> rows2 >> cols2;

    cout << "Enter the elements of the second matrix:" << endl;
    vector<vector<int>> matrix2(rows2, vector<int>(cols2));
    for (int i = 0; i < rows2; ++i)
    {
        for (int j = 0; j < cols2; ++j)
        {
            cin >> matrix2[i][j];
        }
    }

    vector<vector<int>> result = multiplyMatrices(matrix1, matrix2);

    cout << "Resultant Matrix:" << endl;
    printMatrix(result);

    return 0;
}
