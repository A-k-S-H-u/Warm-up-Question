#include <bits/stdc++.h>
using namespace std;

int main()
{

    string input;
    cout << "Enter a string: ";
    cin >> input;
    int n = input.size();
    int i = n - 1;

    for (; i >= 0; i--)
    {
        if (input[i] == '1')
        {
            break;
        }
    }

    for (i = i - 1; i >= 0; i--)
    {
        if (input[i] == '1')
            input[i] = '0';
        else
            input[i] = '1';
    }

    for (int j = 0; j < n; j++)
    {
        cout << input[j] << " ";
    }

    return 0;
}