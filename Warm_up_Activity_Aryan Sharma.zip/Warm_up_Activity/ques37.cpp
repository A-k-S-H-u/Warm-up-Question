#include <iostream>
#include <cmath>

using namespace std;

const int N = 3;

double determinantOfMatrix(int matrix[N][N])
{
    double det = 0;

    for (int i = 0; i < N; i++)
    {
        det += (matrix[0][i] * (matrix[1][(i + 1) % N] * matrix[2][(i + 2) % N] - matrix[1][(i + 2) % N] * matrix[2][(i + 1) % N]));
    }

    return det;
}

int main()
{
    int matrix[N][N];

    cout << "Enter the elements of the " << N << "x" << N << " matrix:" << endl;
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            cout << "Enter element at position " << i + 1 << "," << j + 1 << ": ";
            cin >> matrix[i][j];
        }
    }

    double det = determinantOfMatrix(matrix);
    cout << "Determinant of the matrix is: " << det << endl;

    return 0;
}
