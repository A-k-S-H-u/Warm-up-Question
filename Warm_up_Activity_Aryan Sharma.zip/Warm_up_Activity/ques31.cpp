#include <iostream>
#include <vector>

using namespace std;


int arraySum(const vector<int> &arr, int index)
{
    
    if (index >= arr.size())
    {
        return 0;
    }

    
    return arr[index] + arraySum(arr, index + 1);
}

int main()
{
  
    vector<int> arr = {1, 2, 3, 4, 5};

   
    int sum = arraySum(arr, 0);

    
    cout << "Sum of array elements: " << sum << endl;

    return 0;
}
