
#include <bits/stdc++.h>
using namespace std;

string Binarytohexadecimal(int binaryNumber)
{
    int decimalNumber = 0, i = 0;
    string hexadecimal = "";

    while (binaryNumber != 0)
    {
        decimalNumber += (binaryNumber % 10) * pow(2, i);
        i++;
        binaryNumber /= 10;
    }

    while (decimalNumber != 0)
    {
        if ((decimalNumber % 16) <= 9)
            hexadecimal += (decimalNumber % 16);
        else
        {
            char c = (55 + (decimalNumber % 16));
            hexadecimal = ("" + c) + hexadecimal;
        }

        decimalNumber /= 16;
    }

    return hexadecimal;
}

int main()
{
    long long binaryNumber;
    cout << "Enter a Binary Number: " << endl;
    cin >> binaryNumber;
    cout << "The hexadecimal Number is : " << Binarytohexadecimal(binaryNumber) << endl;
    return 0;
}