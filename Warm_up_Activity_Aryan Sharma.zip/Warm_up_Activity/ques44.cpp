#include <iostream>
#include <string>
#include <unordered_map>

using namespace std;

char findHighestFrequency(const string &inputString)
{
    unordered_map<char, int> charFrequency;

    for (char ch : inputString)
    {
        charFrequency[ch]++;
    }

    char highestFrequencyChar = '\0';
    int highestFrequency = 0;

    for (const auto &entry : charFrequency)
    {
        if (entry.second > highestFrequency)
        {
            highestFrequency = entry.second;
            highestFrequencyChar = entry.first;
        }
    }

    return highestFrequencyChar;
}

int main()
{
    string inputString;

    cout << "Enter a string: ";
    getline(cin, inputString);

    char highestFrequencyChar = findHighestFrequency(inputString);

    if (highestFrequencyChar != '\0')
    {
        cout << "The character with the highest frequency is: " << highestFrequencyChar << endl;
        cout << "Frequency: " << charFrequency[highestFrequencyChar] << endl;
    }
    else
    {
        cout << "The string is empty." << endl;
    }

    return 0;
}
