#include <bits/stdc++.h>
using namespace std;

int main()
{
    long long num;
    int digit;
    int arr[10] = {0};
    cin >> num;
    while (num != 0)
    {
        digit = num % 10;
        arr[digit]++;
        num = num / 10;
    }

    for (int i = 0; i < 10; i++)
    {
        cout << "Frequency of " << i << " is " << arr[i] << endl;
    }
}