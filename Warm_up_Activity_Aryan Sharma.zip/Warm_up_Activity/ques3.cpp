#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cout << "Enter the Number :" << endl;
    cin >> n;
    double ans = sqrt(n);
    cout << ans;
    return 0;
}