#include <iostream>
#include <string>
#include <unordered_set>

using namespace std;

string removeRepeatedCharacters(const string &inputString)
{
    unordered_set<char> seenChars;
    string resultString;

    for (char ch : inputString)
    {

        if (seenChars.find(ch) == seenChars.end())
        {
            resultString += ch;
            seenChars.insert(ch);
        }
    }

    return resultString;
}

int main()
{
    string inputString;

    cout << "Enter a string: ";
    getline(cin, inputString);

    string resultString = removeRepeatedCharacters(inputString);

    cout << "String after removing repeated characters: " << resultString << endl;

    return 0;
}
