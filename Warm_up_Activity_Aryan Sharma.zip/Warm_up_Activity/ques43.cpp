#include <iostream>
#include <string>

using namespace std;

int countOccurrences(const string &inputString, char targetChar)
{
    int count = 0;

    for (char ch : inputString)
    {
        if (ch == targetChar)
        {
            count++;
        }
    }

    return count;
}

int main()
{
    string inputString;
    char targetChar;

    cout << "Enter a string: ";
    getline(cin, inputString);

    cout << "Enter the character to count: ";
    cin >> targetChar;

    int occurrenceCount = countOccurrences(inputString, targetChar);

    cout << "Occurrences of '" << targetChar << "' in the string: " << occurrenceCount << endl;

    return 0;
}
